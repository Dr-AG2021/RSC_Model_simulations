% This function was written by Dr. Atefeh Goshvarpour & Dr. Ateke Goshvarpour 
% for simulating an article ... 
% entitled: "A novel 2-piece rose spiral curve model: application in 
% epileptic EEG classification" considering for puplication in:
% "Computers in Biology and Medicine"
% If you use the code, please cite the article. 
% It aimed to simulate Figure 2 of the article.


clc; close all; clear all;

%%%%%%%%%%%%%%%%%%%%%%%%%%% a 2-piece Rose Spiral Curve %%%%%%%%%%%%%%%%%%%%%%%%%%%
t0 = linspace(1,4*pi,4097);t01 = zeros(1,4097)+1;
a = t01;a = zscore(a);
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);
figure1 = figure;

% Create subplot
subplot1 = subplot(2,4,1,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot1,'on');
hold(subplot1,'all');

% Create plot
plot(a,'Parent',subplot1,'Marker','.','LineStyle','none','Color',[0 0 0]);
axis tight
% Create title
title('Constant','FontWeight','bold','FontSize',12);

% Create xlabel
xlabel('Sample','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create ylabel
ylabel('a','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create subplot
subplot2 = subplot(2,4,5,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot2,'on');
hold(subplot2,'all');

% Create plot
plot(X2,Y2,'Parent',subplot2,'MarkerSize',12,'Marker','.',...
    'LineStyle','none',...
    'Color',[0 0 0]);

% Create xlabel
xlabel('cos(\pi*a)*sin(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

% Create ylabel
ylabel('sin(\pi*a)*cos(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);


%%%%%%%%%%%%%%%%%%%%%%%%%%% a 2-piece Rose Spiral Curve %%%%%%%%%%%%%%%%%%%%%%%%%%%
a = sin(2*pi*t0);a = zscore(a);
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);
% Create subplot
subplot3 = subplot(2,4,2,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot3,'on');
hold(subplot3,'all');

% Create plot
plot(a,'Parent',subplot3,'Marker','.','LineStyle','none','Color',[0 0 0]);
axis tight
% Create title
title('Periodic','FontWeight','bold','FontSize',12);

% Create subplot
subplot4 = subplot(2,4,6,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot4,'on');
hold(subplot4,'all');

% Create plot
plot(X2,Y2,'Parent',subplot4,'MarkerSize',12,'Marker','.',...
    'LineStyle','none',...
    'Color',[0 0 0]);

%%%%%%%%%%%%%%%%%%%%%%%%%%% a 2-piece Rose Spiral Curve %%%%%%%%%%%%%%%%%%%%%%%%%%%
a = rand(4097,1);a = zscore(a);
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);
% Create subplot
subplot5 = subplot(2,4,3,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot5,'on');
hold(subplot5,'all');

% Create plot
plot(a,'Parent',subplot5,'Marker','.','LineStyle','none','Color',[0 0 0]);
axis tight
% Create title
title('Random','FontWeight','bold','FontSize',12);

% Create subplot
subplot6 = subplot(2,4,7,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot6,'on');
hold(subplot6,'all');

% Create plot
plot(X2,Y2,'Parent',subplot6,'MarkerSize',12,'Marker','.',...
    'LineStyle','none',...
    'Color',[0 0 0]);

%%%%%%%%%%%%%%%%%%%%%%%%%%% a 2-piece Rose Spiral Curve %%%%%%%%%%%%%%%%%%%%%%%%%%%
load F:\SET_E\S001.txt
a = S001;a = zscore(a);
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);

% Create subplot
subplot7 = subplot(2,4,4,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot7,'on');
hold(subplot7,'all');

% Create plot
plot(a,'Parent',subplot7,'Marker','.','LineStyle','none','Color',[0 0 0]);
axis tight
% Create title
title('EEG','FontWeight','bold','FontSize',12);

% Create subplot
subplot8 = subplot(2,4,8,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot8,'on');
hold(subplot8,'all');

% Create plot
plot(X2,Y2,'Parent',subplot8,'MarkerSize',12,'Marker','.',...
    'LineStyle','none',...
    'Color',[0 0 0]);


