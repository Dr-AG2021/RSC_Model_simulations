% This function was written by Dr. Atefeh Goshvarpour & Dr. Ateke Goshvarpour 
% for simulating an article ... 
% entitled: "A novel 2-piece rose spiral curve model: application in 
% epileptic EEG classification" considering for puplication in:
% "Computers in Biology and Medicine"
% If you use the code, please cite the article. 
% It aimed to simulate Figures 3 to 6 of the article.

clc; close all; clear all;

j1 = [200 1000 2000 3000 4000];figure1 = figure;
for k = 1:5
    j = j1(k);
%%%%%%%%%%%%%%%%%%%%%%%%%%% a 2-piece Rose Spiral Curve %%%%%%%%%%%%%%%%%%%%%%%%%%%

t01 = zeros(1,j)+5;
a = t01;a = zscore(a);
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);

% Create subplot
subplot1 = subplot(2,5,k,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot1,'on');
hold(subplot1,'all');

% Create plot
plot(a,'Parent',subplot1,'Marker','.','LineStyle','none','Color',[0 0 0]);
axis tight
% Create title
title('Constant','FontWeight','bold','FontSize',12);

% Create xlabel
xlabel('Sample','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create ylabel
ylabel('a','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create subplot
subplot2 = subplot(2,5,k+5,'Parent',figure1,'FontWeight','bold','FontSize',11);

box(subplot2,'on');
hold(subplot2,'all');

% Create plot
plot(X2,Y2,'Parent',subplot2,'MarkerSize',6,'Marker','o',...
    'MarkerFacecolor','k',...
    'LineStyle','none',...
    'Color',[0 0 0]);

% Create xlabel
xlabel('cos(\pi*a)*sin(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

% Create ylabel
ylabel('sin(\pi*a)*cos(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

axis tight

end
j1 = [200 1000 2000 3000 4000];figure2 = figure;
for k = 1:5
    j = j1(k);
%%%%%%%%%%%%%%%%%%%%%%%%%%% a Periodic signal %%%%%%%%%%%%%%%%%%%%%%%%%%%
t0 = linspace(1,4*pi,j);
a = sin(2*pi*t0);a = zscore(a);
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);

% Create subplot
subplot1 = subplot(2,5,k,'Parent',figure2,'FontWeight','bold','FontSize',11);

box(subplot1,'on');
hold(subplot1,'all');

% Create plot
plot(a,'Parent',subplot1,'Marker','.','LineStyle','none','Color',[0 0 0]);
axis tight
% Create title
title('Periodic','FontWeight','bold','FontSize',12);

% Create xlabel
xlabel('Sample','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create ylabel
ylabel('a','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create subplot
subplot2 = subplot(2,5,k+5,'Parent',figure2,'FontWeight','bold','FontSize',11);

box(subplot2,'on');
hold(subplot2,'all');

% Create plot
plot(X2,Y2,'Parent',subplot2,'MarkerSize',12,'Marker','.',...
    'LineStyle','none',...
    'Color',[0 0 0]);

% Create xlabel
xlabel('cos(\pi*a)*sin(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

% Create ylabel
ylabel('sin(\pi*a)*cos(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

end
j1 = [200 1000 2000 3000 4000];figure3 = figure;
for k = 1:5
    j = j1(k);
%%%%%%%%%%%%%%%%%%%%%%%%%%% a Random signal %%%%%%%%%%%%%%%%%%%%%%%%%%%
a = rand(j,1);a = zscore(a);
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);


% Create subplot
subplot1 = subplot(2,5,k,'Parent',figure3,'FontWeight','bold','FontSize',11);

box(subplot1,'on');
hold(subplot1,'all');

% Create plot
plot(a,'Parent',subplot1,'Marker','.','LineStyle','none','Color',[0 0 0]);
axis tight
% Create title
title('Random','FontWeight','bold','FontSize',12);

% Create xlabel
xlabel('Sample','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create ylabel
ylabel('a','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create subplot
subplot2 = subplot(2,5,k+5,'Parent',figure3,'FontWeight','bold','FontSize',11);

box(subplot2,'on');
hold(subplot2,'all');

% Create plot
plot(X2,Y2,'Parent',subplot2,'MarkerSize',12,'Marker','.',...
    'LineStyle','none',...
    'Color',[0 0 0]);

% Create xlabel
xlabel('cos(\pi*a)*sin(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

% Create ylabel
ylabel('sin(\pi*a)*cos(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

end
j1 = [200 1000 2000 3000 4000];figure4 = figure;
for k = 1:5
    j = j1(k);
%%%%%%%%%%%%%%%%%%%%%%%%%%% a 2-piece Rose Spiral Curve %%%%%%%%%%%%%%%%%%%%%%%%%%%
load F:\SET_E\S001.txt
a = S001(1:j);a = zscore(a);
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);


% Create subplot
subplot1 = subplot(2,5,k,'Parent',figure4,'FontWeight','bold','FontSize',11);

box(subplot1,'on');
hold(subplot1,'all');

% Create plot
plot(a,'Parent',subplot1,'Marker','.','LineStyle','none','Color',[0 0 0]);
axis tight
% Create title
title('EEG','FontWeight','bold','FontSize',12);

% Create xlabel
xlabel('Sample','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create ylabel
ylabel('a','FontWeight','bold','FontSize',12,'FontAngle','italic',...
    'Color',[0 0 1]);

% Create subplot
subplot2 = subplot(2,5,k+5,'Parent',figure4,'FontWeight','bold','FontSize',11);

box(subplot2,'on');
hold(subplot2,'all');

% Create plot
plot(X2,Y2,'Parent',subplot2,'MarkerSize',12,'Marker','.',...
    'LineStyle','none',...
    'Color',[0 0 0]);

% Create xlabel
xlabel('cos(\pi*a)*sin(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

% Create ylabel
ylabel('sin(\pi*a)*cos(a)','FontWeight','bold','FontSize',12,...
    'FontAngle','italic',...
    'Color',[1 0 0]);

end