% This function was written by Dr. Atefeh Goshvarpour & Dr. Ateke Goshvarpour 
% for simulating an article ... 
% entitled: "A novel 2-piece rose spiral curve model: application in 
% epileptic EEG classification" considering for puplication in:
% "Computers in Biology and Medicine"
% If you use the code, please cite the article.

% Input: EEG Data available at Bonn Database,
% output: The introduced RSC features
tic
clc; close all; clear all;
%% load Data & calculate RSC-base features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SET E %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for d = 1:9 % Subject Number  
    s = ['load F:\SET_E\S00' int2str(d) '.txt' ];
    eval (s);
    s = ['X1 = S00' int2str(d) ';'];
    eval (s);
    fs(d,:)=rose_f(X1);
end
for d = 10:99 % Subject Number  
    s = ['load F:\SET_E\S0' int2str(d) '.txt' ];
    eval (s); 
    s = ['X1 = S0' int2str(d) ';'];
    eval (s);
    fs(d,:)=rose_f(X1);
end
for d = 100 % Subject Number  
    s = ['load F:\SET_E\S' int2str(d) '.txt' ];
    eval (s);
    s = ['X1 = S' int2str(d) ';'];
    eval (s);
    fs(d,:)=rose_f(X1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SET A %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for d = 1:9 % Subject Number  
    s = ['load F:\SET_A\Z00' int2str(d) '.txt' ];
    eval (s);
    s = ['X1 = Z00' int2str(d) ';'];
    eval (s);
    fz(d,:)=rose_f(X1);
end
for d = 10:99 % Subject Number  
    s = ['load F:\SET_A\Z0' int2str(d) '.txt' ];
    eval (s);
    s = ['X1 = Z0' int2str(d) ';'];
    eval (s);
    fz(d,:)=rose_f(X1);
end
for d = 100 % Subject Number  
    s = ['load F:\SET_A\Z' int2str(d) '.txt' ];
    eval (s);
    s = ['X1 = Z' int2str(d) ';'];
    eval (s);
    fz(d,:)=rose_f(X1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SET D %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for d = 1:9 % Subject Number  
    s = ['load F:\SET_D\F00' int2str(d) '.txt' ];
    eval (s);
    s = ['X1 = F00' int2str(d) ';'];
    eval (s);
    ff(d,:)=rose_f(X1);
end
for d = 10:99 % Subject Number  
    s = ['load F:\SET_D\F0' int2str(d) '.txt' ];
    eval (s);
    s = ['X1 = F0' int2str(d) ';'];
    eval (s);
    ff(d,:)=rose_f(X1);
end
for d = 100 % Subject Number  
    s = ['load F:\SET_D\F' int2str(d) '.txt' ];
    eval (s);
    s = ['X1 = F' int2str(d) ';'];
    eval (s);
    ff(d,:)=rose_f(X1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Combine all features in a vector
Feat_1 = [ff;fs;fz];
save Feat_1 Feat_1
toc