% This function was written by Dr. Atefeh Goshvarpour & Dr. Ateke Goshvarpour 
% for simulating an article ... 
% entitled: "A novel 2-piece rose spiral curve model: application in 
% epileptic EEG classification" considering for puplication in:
% "Computers in Biology and Medicine"
% If you use the code, please cite the article. 
% It aimed to simulate equations (1) to (6) of the article.

function feat = rose_f(X1)
% X1: input data
% feat: output features including F1, F2, F3, and F4

a = zscore(X1);

%%%%%%%%%%%%%%%%%%%%%%%%%%% a 2-piece Rose Spiral Curve %%%%%%%%%%%%%%%%%%%%%%%%%%%
X2 = cos(pi*a).*sin(a);
Y2 = sin(pi*a).*cos(a);

%%%%%%F1:Summation of distances from each point to coordinate center%%%%%%
for k = 1:length(X2)
    F1_1(k) = X2(k)^2+Y2(k)^2;
end
F1 = sum(F1_1);
%%%%%%F2:Summation of angles from each point to coordinate center%%%%%%
for k = 1:length(X2)
    F2_1(k) = atan2(Y2(k),X2(k));
end
F2 = sum(F2_1);
%%%%%%%%%%%%%%%%%%%%%F3:Summation of rectangles area%%%%%%%%%%%%%%%%%%%%%
for k = 1:length(X2)
    D45(k) = abs(X2(k)-Y2(k))/sqrt(2);
    D135(k) = abs(X2(k)+Y2(k))/sqrt(2);
    F3_1(k)=D45(k)*D135(k)/2;
end
F3 = sum(F3_1);
%%%%%%%%%%%%%%%%%%%%%F4:Summation of triangle area%%%%%%%%%%%%%%%%%%%%%
for k = 1:length(X2)-2
    A = [X2(k),X2(k+1),X2(k+2);Y2(k),Y2(k+1),Y2(k+2);1,1,1];
    A1(k) = det(A);
    F4_1(k) = abs(A1(k));
 end
F4 = 0.5*sum(F4_1);

%% Total features
feat = [F1;F2;F3;F4];